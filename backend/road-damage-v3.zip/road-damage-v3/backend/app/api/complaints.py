from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status, WebSocket, WebSocketDisconnect, Request
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import uuid, os, shutil, hashlib, math

from app.database import get_db
from app.models.models import Complaint, User, FieldOfficer, SeverityLevel, ComplaintStatus, Notification
from app.services.auth_service import get_current_user, get_current_officer
from app.services.ai_service import analyze_image

router = APIRouter()
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

try:
    from ws_manager import manager as ws_manager
    WS_ENABLED = True
except ImportError:
    WS_ENABLED = False

def generate_complaint_id():
    return f"RD-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:6].upper()}"

def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371000
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

def get_area_type(address: str) -> str:
    if not address:
        return "general"
    addr_lower = address.lower()
    if any(w in addr_lower for w in ["hospital", "clinic", "medical", "health", "emergency"]):
        return "hospital"
    elif any(w in addr_lower for w in ["school", "college", "university", "academy", "institute"]):
        return "school"
    elif any(w in addr_lower for w in ["highway", "nh-", "sh-", "national highway", "expressway"]):
        return "highway"
    elif any(w in addr_lower for w in ["mall", "market", "bazaar", "shopping", "commercial"]):
        return "market"
    elif any(w in addr_lower for w in ["industrial", "factory", "warehouse", "plant"]):
        return "industrial"
    else:
        return "residential"

def calculate_priority_score(severity: str, damage_type: str, area_type: str, report_count: int = 1) -> float:
    # Damage size score (0-35)
    damage_score = {"high": 35, "medium": 20, "low": 10}.get(severity.lower(), 10)
    
    # Damage type modifier
    type_mod = {"pothole": 5, "multiple": 8, "crack": 3, "surface_damage": 2}.get(str(damage_type).lower(), 0)
    
    # Area criticality (0-30)
    area_score = {"hospital": 30, "school": 25, "highway": 25, "market": 20, "industrial": 15, "residential": 10, "general": 8}.get(area_type, 10)
    
    # Traffic density estimate (0-20)
    traffic = {"hospital": 20, "school": 18, "market": 18, "highway": 16, "industrial": 12, "residential": 8, "general": 6}.get(area_type, 8)
    
    # Accident risk (0-15)
    risk = {"pothole": 15, "multiple": 14, "crack": 8, "surface_damage": 6}.get(str(damage_type).lower(), 6)
    
    # Report count bonus (more citizens reporting = higher priority)
    report_bonus = min(report_count * 2, 10)
    
    total = damage_score + type_mod + area_score + traffic + risk + report_bonus
    return round(min(total, 100), 1)

def image_hash(filepath: str) -> str:
    try:
        with open(filepath, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()
    except:
        return ""

def create_notification(db: Session, user_id: int, complaint_id: str, message: str, notif_type: str = "info"):
    try:
        notif = Notification(
            user_id=user_id,
            complaint_id=complaint_id,
            message=message,
            type=notif_type,
            is_read=False
        )
        db.add(notif)
        db.commit()
    except Exception as e:
        db.rollback()
        print(f"Notification error: {e}")

@router.websocket("/ws/officer")
async def websocket_officer(websocket: WebSocket):
    if not WS_ENABLED:
        await websocket.close(); return
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)

@router.post("/submit")
async def submit_complaint(
    request: Request,
    latitude: float = Form(...),
    longitude: float = Form(...),
    address: Optional[str] = Form(None),
    image: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    try:
        # Save image
        ext = image.filename.split(".")[-1] if image.filename and "." in image.filename else "jpg"
        filename = f"{uuid.uuid4()}.{ext}"
        filepath = os.path.join(UPLOAD_DIR, filename)
        image_data = await image.read()
        with open(filepath, "wb") as f:
            f.write(image_data)

        # AI detection
        try:
            detection = analyze_image(filepath)
            damage_type = detection.damage_type
            severity = detection.severity
            confidence = detection.confidence
            description = detection.description
        except Exception:
            damage_type = "surface_damage"
            severity = SeverityLevel.MEDIUM
            confidence = 0.75
            description = "Road damage detected."

        # Image hash for duplicate detection
        img_hash = image_hash(filepath)
        
        # Reverse geocode if no address
        if not address:
            address = f"{latitude:.5f}, {longitude:.5f}"
        
        # Area type detection
        area_type = get_area_type(address)

        # Smart duplicate detection: image hash OR 50m radius + same damage type
        existing = None
        
        # Check image hash
        if img_hash:
            existing = db.query(Complaint).filter(
                Complaint.image_hash == img_hash,
                Complaint.status != ComplaintStatus.COMPLETED
            ).first()
        
        # Check 50m radius
        if not existing:
            nearby = db.query(Complaint).filter(
                Complaint.latitude.between(latitude - 0.001, latitude + 0.001),
                Complaint.longitude.between(longitude - 0.001, longitude + 0.001),
                Complaint.status != ComplaintStatus.COMPLETED
            ).all()
            for n in nearby:
                dist = haversine_distance(latitude, longitude, n.latitude, n.longitude)
                dmg_match = str(n.damage_type).split(".")[-1].lower() == str(damage_type).split(".")[-1].lower()
                if dist <= 50 and dmg_match:
                    existing = n
                    break

        if existing:
            # Increment report count
            try:
                existing.report_count = (existing.report_count or 1) + 1
                existing.priority_score = calculate_priority_score(
                    existing.severity.value if hasattr(existing.severity, 'value') else str(existing.severity),
                    str(existing.damage_type), area_type, existing.report_count
                )
                db.commit()
            except:
                pass
            return {
                "warning": "duplicate",
                "message": f"Similar complaint already reported nearby: {existing.complaint_id}. Report count updated to {getattr(existing, 'report_count', 2)}.",
                "existing_complaint_id": existing.complaint_id,
                "distance_meters": int(haversine_distance(latitude, longitude, existing.latitude, existing.longitude)) if not img_hash else 0
            }

        # Get best officer (least loaded in same zone)
        officer = None
        try:
            officers = db.query(FieldOfficer).filter(FieldOfficer.is_active == True).all()
            if officers:
                # Pick officer with fewest active complaints
                best = None
                best_count = 9999
                for o in officers:
                    cnt = db.query(Complaint).filter(
                        Complaint.officer_id == o.id,
                        Complaint.status.in_([ComplaintStatus.PENDING, ComplaintStatus.ASSIGNED, ComplaintStatus.IN_PROGRESS])
                    ).count()
                    if cnt < best_count:
                        best_count = cnt
                        best = o
                officer = best
        except:
            officer = db.query(FieldOfficer).first()

        # Priority score
        sev_val = severity.value if hasattr(severity, 'value') else str(severity)
        dmg_val = damage_type.value if hasattr(damage_type, 'value') else str(damage_type)
        priority = calculate_priority_score(sev_val, dmg_val, area_type, 1)

        complaint = Complaint(
            complaint_id=generate_complaint_id(),
            user_id=current_user.id,
            officer_id=officer.id if officer else None,
            latitude=latitude,
            longitude=longitude,
            address=address,
            damage_type=damage_type,
            severity=severity,
            ai_confidence=confidence,
            description=description,
            image_url=f"/uploads/{filename}",
            status=ComplaintStatus.ASSIGNED if officer else ComplaintStatus.PENDING,
            allocated_fund=0.0,
            priority_score=priority,
            is_duplicate=False,
            area_type=area_type,
            report_count=1
        )
        
        try:
            complaint.image_hash = img_hash
        except:
            pass

        db.add(complaint)
        try:
            current_user.points = (current_user.points or 0) + 10
        except:
            pass
        db.commit()
        db.refresh(complaint)

        # Create notification for citizen
        create_notification(
            db, current_user.id, complaint.complaint_id,
            f"✅ Complaint {complaint.complaint_id} submitted successfully. Severity: {sev_val.upper()}. Priority Score: {priority}.",
            "submitted"
        )

        # Notify officer
        try:
            from app.services.notification_service import notify_officer
            if officer:
                notify_officer(officer, complaint)
        except:
            pass

        # WebSocket broadcast
        try:
            if WS_ENABLED:
                await ws_manager.broadcast_new_complaint(complaint)
        except:
            pass

        return {
            "id": complaint.id,
            "complaint_id": complaint.complaint_id,
            "latitude": complaint.latitude,
            "longitude": complaint.longitude,
            "address": complaint.address,
            "damage_type": dmg_val,
            "severity": sev_val,
            "ai_confidence": complaint.ai_confidence,
            "description": complaint.description,
            "image_url": complaint.image_url,
            "status": complaint.status.value if hasattr(complaint.status, 'value') else str(complaint.status),
            "priority_score": priority,
            "area_type": area_type,
            "created_at": str(complaint.created_at)
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{complaint_id}/after-photo")
async def upload_after_photo(
    complaint_id: str,
    image: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_officer: FieldOfficer = Depends(get_current_officer)
):
    c = db.query(Complaint).filter(Complaint.complaint_id == complaint_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    ext = image.filename.split(".")[-1] if image.filename and "." in image.filename else "jpg"
    filename = f"{uuid.uuid4()}_after.{ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)
    with open(filepath, "wb") as f:
        shutil.copyfileobj(image.file, f)
    c.officer_notes = (c.officer_notes or "") + f"\n[AFTER_PHOTO:/uploads/{filename}]"
    db.commit()
    return {"after_image_url": f"/uploads/{filename}"}

@router.get("/my")
def my_complaints(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    token_user = current_user
    complaints = db.query(Complaint).filter(
        Complaint.user_id == token_user.id
    ).order_by(Complaint.created_at.desc()).all()
    return [serialize_complaint(c) for c in complaints]

@router.get("/notifications/my")
def my_notifications(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    try:
        notifs = db.query(Notification).filter(
            Notification.user_id == current_user.id
        ).order_by(Notification.created_at.desc()).limit(50).all()
        return [{"id": n.id, "complaint_id": n.complaint_id, "message": n.message, "type": n.type, "is_read": n.is_read, "created_at": str(n.created_at)} for n in notifs]
    except:
        return []

@router.post("/notifications/read-all")
def mark_all_read(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    try:
        db.query(Notification).filter(Notification.user_id == current_user.id).update({"is_read": True})
        db.commit()
    except:
        db.rollback()
    return {"message": "ok"}

@router.get("/priority/ranking")
def priority_ranking(db: Session = Depends(get_db), current_officer: FieldOfficer = Depends(get_current_officer)):
    complaints = db.query(Complaint).filter(
        Complaint.status != ComplaintStatus.COMPLETED
    ).order_by(Complaint.priority_score.desc()).limit(20).all()
    return [serialize_complaint(c) for c in complaints]

@router.get("/budget/recommendations")
def budget_recommendations(db: Session = Depends(get_db), current_officer: FieldOfficer = Depends(get_current_officer)):
    complaints = db.query(Complaint).filter(
        Complaint.status != ComplaintStatus.COMPLETED,
        Complaint.allocated_fund == 0
    ).order_by(Complaint.priority_score.desc()).limit(20).all()
    
    result = []
    for c in complaints:
        sev = c.severity.value if hasattr(c.severity, 'value') else str(c.severity)
        dmg = str(c.damage_type).split(".")[-1].lower()
        area = getattr(c, 'area_type', 'residential') or 'residential'
        
        base = {"pothole": 25000, "crack": 15000, "surface_damage": 20000, "multiple": 40000}.get(dmg, 20000)
        sev_mult = {"high": 2.5, "medium": 1.5, "low": 1.0}.get(sev, 1.5)
        area_mult = {"hospital": 1.5, "school": 1.4, "highway": 1.8, "market": 1.2, "industrial": 1.3, "residential": 1.0}.get(area, 1.0)
        
        budget = int(base * sev_mult * area_mult)
        area_label = {"hospital": "Hospital Zone", "school": "School Zone", "highway": "Highway", "market": "Market Area", "industrial": "Industrial", "residential": "Residential"}.get(area, "General")
        
        result.append({
            "complaint_id": c.complaint_id,
            "address": c.address,
            "area_type": area,
            "area_label": area_label,
            "damage_type": dmg,
            "severity": sev,
            "priority_score": c.priority_score or 0,
            "estimated_budget": budget,
            "reason": f"{area_label}, {sev} severity {dmg}"
        })
    return result

@router.get("/{complaint_id}")
def get_complaint(complaint_id: str, db: Session = Depends(get_db)):
    c = db.query(Complaint).filter(Complaint.complaint_id == complaint_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    return serialize_complaint(c)

@router.get("/")
def list_complaints(
    status: Optional[str] = None,
    severity: Optional[str] = None,
    skip: int = 0, limit: int = 100,
    db: Session = Depends(get_db),
    current_officer: FieldOfficer = Depends(get_current_officer)
):
    query = db.query(Complaint).filter(Complaint.officer_id == current_officer.id)
    if status:
        try:
            query = query.filter(Complaint.status == ComplaintStatus(status))
        except:
            pass
    if severity:
        try:
            query = query.filter(Complaint.severity == SeverityLevel(severity))
        except:
            pass
    complaints = query.order_by(Complaint.priority_score.desc(), Complaint.created_at.desc()).offset(skip).limit(limit).all()
    return [serialize_complaint(c) for c in complaints]

@router.patch("/{complaint_id}/status")
async def update_status(
    complaint_id: str,
    request: Request,
    db: Session = Depends(get_db),
    current_officer: FieldOfficer = Depends(get_current_officer)
):
    body = await request.json()
    c = db.query(Complaint).filter(
        Complaint.complaint_id == complaint_id,
        Complaint.officer_id == current_officer.id
    ).first()
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    
    old_status = c.status.value if hasattr(c.status, 'value') else str(c.status)
    try:
        c.status = ComplaintStatus(body.get("status", old_status))
    except:
        pass
    if body.get("officer_notes"):
        c.officer_notes = body["officer_notes"]
    if c.status == ComplaintStatus.COMPLETED:
        c.resolved_at = datetime.utcnow()
    db.commit()
    db.refresh(c)
    
    # Notification to citizen
    new_status = c.status.value if hasattr(c.status, 'value') else str(c.status)
    msg_map = {
        "in_progress": f"🔧 Repair work has started on {complaint_id}. Officer: {current_officer.name}",
        "completed": f"✅ Road repair completed for {complaint_id}. Thank you for reporting!",
        "assigned": f"👮 Officer {current_officer.name} has been assigned to {complaint_id}",
        "rejected": f"❌ Complaint {complaint_id} was reviewed but could not be processed."
    }
    if new_status in msg_map:
        create_notification(db, c.user_id, complaint_id, msg_map[new_status], new_status)
    
    try:
        if WS_ENABLED:
            await ws_manager.broadcast_status_update(c)
    except:
        pass
    return serialize_complaint(c)

@router.patch("/{complaint_id}/fund")
async def allocate_fund(
    complaint_id: str,
    request: Request,
    db: Session = Depends(get_db),
    current_officer: FieldOfficer = Depends(get_current_officer)
):
    body = await request.json()
    c = db.query(Complaint).filter(Complaint.complaint_id == complaint_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    try:
        c.allocated_fund = body.get("amount", 0)
        c.fund_note = body.get("note", "")
        c.fund_allocated_at = datetime.utcnow()
        db.commit()
        # Notify citizen
        create_notification(db, c.user_id, complaint_id,
            f"💰 Budget of ₹{int(c.allocated_fund):,} allocated to {complaint_id}. Work will begin soon.",
            "funded")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    return serialize_complaint(c)

def serialize_complaint(c):
    result = {
        "id": c.id,
        "complaint_id": c.complaint_id,
        "latitude": c.latitude,
        "longitude": c.longitude,
        "address": c.address,
        "damage_type": str(c.damage_type).split(".")[-1].lower() if c.damage_type else "surface_damage",
        "severity": str(c.severity).split(".")[-1].lower() if c.severity else "medium",
        "ai_confidence": c.ai_confidence,
        "description": c.description,
        "image_url": c.image_url,
        "status": str(c.status).split(".")[-1].lower() if c.status else "pending",
        "officer_notes": c.officer_notes,
        "created_at": str(c.created_at),
        "updated_at": str(c.updated_at) if c.updated_at else None,
        "resolved_at": str(c.resolved_at) if c.resolved_at else None,
    }
    for field in ["allocated_fund", "fund_note", "priority_score", "is_duplicate", "duplicate_of", "area_type", "report_count", "rainfall_mm", "traffic_volume", "road_age_years", "weather_condition", "image_hash"]:
        try:
            result[field] = getattr(c, field, None)
        except:
            result[field] = None
    # Officer info
    try:
        if c.officer:
            result["officer_name"] = c.officer.name
            result["officer_zone"] = c.officer.zone
    except:
        result["officer_name"] = None
        result["officer_zone"] = None
    # Citizen info
    try:
        if c.user:
            result["citizen_name"] = c.user.name
            result["citizen_phone"] = c.user.phone
    except:
        result["citizen_name"] = None
        result["citizen_phone"] = None
    return result
