# RoadWatch v3 — Complete Upgrade Guide

## Files to install:

### Step 1 — Replace backend files
```
copy "complaints.py"   → D:\python\road-damage-app\backend\app\api\complaints.py
copy "models.py"       → D:\python\road-damage-app\backend\app\models\models.py
```

### Step 2 — Run database migration
```powershell
cd D:\python\road-damage-app\backend
python ..\migrate_v2.py
```
Expected output: "✅ Migration complete!"

### Step 3 — Copy HTML files
```powershell
copy "citizen.html"   → D:\python\road-damage-app\backend\static\citizen.html
copy "dashboard.html" → D:\python\road-damage-app\backend\static\dashboard.html
```

### Step 4 — Restart backend
```powershell
cd D:\python\road-damage-app\backend
uvicorn app.main:app --reload
```

### Step 5 — Test
- http://localhost:8000/citizen     → Citizen portal
- http://localhost:8000/dashboard   → Officer dashboard
- http://localhost:8000/admin       → Admin panel

---

## What's new in v3:

### Citizen Portal (citizen.html)
- ✅ Leaflet map (no Google API needed)
- ✅ Auto GPS + reverse geocode to real address
- ✅ Area type detection (Hospital/School/Highway/Market/Residential)
- ✅ Area badge shown before submit
- ✅ AI priority score shown in result card
- ✅ Duplicate warning with distance shown
- ✅ Push notifications tab with unread badge count
- ✅ Status filter on My Reports
- ✅ Priority score badge on each complaint card
- ✅ Leaflet map in complaint detail (no Google API)

### Officer Dashboard (dashboard.html)
- ✅ Priority Score badge on every complaint card
- ✅ Area zone classification badge
- ✅ Report count badge (×3 reports)
- ✅ New "Priority" tab — AI-ranked top 10 + budget recommendations
- ✅ Priority Score breakdown (Damage/Area/Traffic/Risk bars)
- ✅ Area Zone box with icon and color in detail panel
- ✅ Budget allocation form with AI-suggested amount
- ✅ Leaflet map (replaces Google Maps — no API key needed)
- ✅ Before/After slider comparison
- ✅ Citizen info box with report count

### Backend (complaints.py)
- ✅ Haversine 50m radius duplicate detection
- ✅ MD5 image hash duplicate detection
- ✅ Auto area type detection from address
- ✅ AI priority score formula:
    Priority = Damage(35) + Type(8) + Area(30) + Traffic(20) + Risk(15) + Reports(10)
- ✅ Hospital zone = highest priority
- ✅ Auto-assigns officer with fewest active complaints
- ✅ Push notifications created on: submit, status change, fund allocation
- ✅ GET /api/complaints/priority/ranking
- ✅ GET /api/complaints/budget/recommendations
- ✅ GET /api/complaints/notifications/my
- ✅ POST /api/complaints/notifications/read-all

### Database (models.py + migrate_v2.py)
- ✅ notifications table (new)
- ✅ complaints.area_type column
- ✅ complaints.image_hash column
- ✅ complaints.report_count column
- ✅ All existing data preserved

## Priority Score Formula:
| Zone        | Score |
|-------------|-------|
| Hospital    | P70+  |
| School      | P60+  |
| Highway     | P60+  |
| Market      | P50+  |
| Residential | P30+  |

High severity pothole in hospital zone = P85+ → Immediate priority
